package Model;


public class EmployeeBean {
	private  String empid;
	private String empname;
	private double empsalary;
	private String emplocation;
	private float empexp;
	private double empemi;
	private double emploan;
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public double getEmpsalary() {
		return empsalary;
	}
	public void setEmpsalary(double empsalary) {
		this.empsalary = empsalary;
	}
	public String getEmplocation() {
		return emplocation;
	}
	public void setEmplocation(String emplocation) {
		this.emplocation = emplocation;
	}
	public float getEmpexp() {
		return empexp;
	}
	public void setEmpexp(float empexp) {
		this.empexp = empexp;
	}
	public double getEmpemi() {
		return empemi;
	}
	public void setEmpemi(double empemi) {
		this.empemi = empemi;
	}
	public double getEmploan() {
		return emploan;
	}
	public void setEmploan(double emploan) {
		this.emploan = emploan;
	}
	

}
